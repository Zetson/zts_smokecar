resource_manifest_version '05cfa83c-a124-4cfa-a768-c24a5811d8f9'

server_script {
    "server.lua",
}

client_script {
    "client.lua",
}



---muie la invidiosi 
---https://discord.gg/RkxaCmtYHm
---https://discord.gg/rvKvzHN8Hb



---pt necunoscatori , cand esti in masina si apesi X iese fum pe toba 
---https://cdn.discordapp.com/attachments/825672254889263118/825693062478954506/unknown.png