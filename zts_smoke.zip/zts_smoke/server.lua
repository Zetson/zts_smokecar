RegisterServerEvent("ZET:sync")
AddEventHandler("ZET:pornestefum", function(carid)
    TriggerClientEvent("ZET:pornestefum", -1, carid)
end)

RegisterServerEvent("ZET:syncstop")
AddEventHandler("ZET:syncstop", function(carid)
    TriggerClientEvent("ZET:oprestefum", -1, carid)
end)